﻿namespace ESPRoom_Desktop
{
    partial class app
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.pole = new System.Windows.Forms.RichTextBox();
            this.get_all = new System.Windows.Forms.Button();
            this.clear_data = new System.Windows.Forms.Button();
            this.warnings = new System.Windows.Forms.Button();
            this.id_get = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.id_choice = new System.Windows.Forms.TextBox();
            this.savepath = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // pole
            // 
            this.pole.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pole.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pole.Location = new System.Drawing.Point(0, 200);
            this.pole.Name = "pole";
            this.pole.Size = new System.Drawing.Size(809, 249);
            this.pole.TabIndex = 0;
            this.pole.Text = "";
            // 
            // get_all
            // 
            this.get_all.Dock = System.Windows.Forms.DockStyle.Top;
            this.get_all.Location = new System.Drawing.Point(0, 0);
            this.get_all.Name = "get_all";
            this.get_all.Size = new System.Drawing.Size(809, 23);
            this.get_all.TabIndex = 1;
            this.get_all.Text = "GET ALL";
            this.get_all.UseVisualStyleBackColor = true;
            this.get_all.Click += new System.EventHandler(this.get_all_Click);
            // 
            // clear_data
            // 
            this.clear_data.Dock = System.Windows.Forms.DockStyle.Top;
            this.clear_data.Location = new System.Drawing.Point(0, 23);
            this.clear_data.Name = "clear_data";
            this.clear_data.Size = new System.Drawing.Size(809, 23);
            this.clear_data.TabIndex = 2;
            this.clear_data.Text = "CLEAR DATA";
            this.clear_data.UseVisualStyleBackColor = true;
            this.clear_data.Click += new System.EventHandler(this.clear_data_Click);
            // 
            // warnings
            // 
            this.warnings.Dock = System.Windows.Forms.DockStyle.Top;
            this.warnings.Location = new System.Drawing.Point(0, 46);
            this.warnings.Name = "warnings";
            this.warnings.Size = new System.Drawing.Size(809, 23);
            this.warnings.TabIndex = 3;
            this.warnings.Text = "WARNINGS";
            this.warnings.UseVisualStyleBackColor = true;
            // 
            // id_get
            // 
            this.id_get.Dock = System.Windows.Forms.DockStyle.Top;
            this.id_get.Location = new System.Drawing.Point(0, 69);
            this.id_get.Name = "id_get";
            this.id_get.Size = new System.Drawing.Size(809, 23);
            this.id_get.TabIndex = 4;
            this.id_get.Text = "GET BY ID";
            this.id_get.UseVisualStyleBackColor = true;
            this.id_get.Click += new System.EventHandler(this.id_get_Click);
            // 
            // save
            // 
            this.save.Dock = System.Windows.Forms.DockStyle.Top;
            this.save.Location = new System.Drawing.Point(0, 92);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(809, 23);
            this.save.TabIndex = 5;
            this.save.Text = "SAVE";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // id_choice
            // 
            this.id_choice.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.id_choice.Dock = System.Windows.Forms.DockStyle.Top;
            this.id_choice.Location = new System.Drawing.Point(0, 115);
            this.id_choice.Name = "id_choice";
            this.id_choice.Size = new System.Drawing.Size(809, 22);
            this.id_choice.TabIndex = 6;
            this.id_choice.Text = "INSERT ID HERE";
            this.id_choice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // savepath
            // 
            this.savepath.Filter = "Pliki tekstowe|*.txt";
            // 
            // app
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ESPRoom_Desktop.Properties.Resources.bg_app;
            this.ClientSize = new System.Drawing.Size(809, 449);
            this.Controls.Add(this.id_choice);
            this.Controls.Add(this.save);
            this.Controls.Add(this.id_get);
            this.Controls.Add(this.warnings);
            this.Controls.Add(this.clear_data);
            this.Controls.Add(this.get_all);
            this.Controls.Add(this.pole);
            this.Name = "app";
            this.Text = "ESPRoom";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox pole;
        private System.Windows.Forms.Button get_all;
        private System.Windows.Forms.Button clear_data;
        private System.Windows.Forms.Button warnings;
        private System.Windows.Forms.Button id_get;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.TextBox id_choice;
        private System.Windows.Forms.SaveFileDialog savepath;
    }
}

