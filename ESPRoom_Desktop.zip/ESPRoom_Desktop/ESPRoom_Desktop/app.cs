﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ESPRoom_Desktop
{
    public partial class app : Form
    {
        SqlConnection db;
        public app()
        {
            InitializeComponent();
            var cb = new SqlConnectionStringBuilder();
            cb.DataSource = "esproom.database.windows.net";
            cb.UserID = "esproom";
            cb.Password = "ESPmanage1";
            cb.InitialCatalog = "ESPRoom";
            db = new SqlConnection(cb.ConnectionString);
            db.Open();
        }

        private void get_all_Click(object sender, EventArgs e) {
            pole.Clear();
            SqlCommand cmd = new SqlCommand("SELECT * FROM pomiary",db);
            SqlDataReader DataReader = cmd.ExecuteReader();
            while (DataReader.Read())
            {
                pole.Text += "Temperatura: " + DataReader.GetValue(1) + " | Ciśnienie: " + DataReader.GetValue(2) + " | Wysokość: " + DataReader.GetValue(3) + " | Wilgotność: " + DataReader.GetValue(4) + " | Data: " + DataReader.GetValue(5) + " | Urządzenie: " + DataReader.GetValue(6) + "\n";
            }
        }

        private void save_Click(object sender, EventArgs e)
        {
            if (savepath.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(savepath.FileName, pole.Text);
            }
        }

        private void clear_data_Click(object sender, EventArgs e)
        {
            pole.Clear();
        }

        private void id_get_Click(object sender, EventArgs e)
        {
            pole.Clear();
            for(int i = 0; i < id_choice.Text.Length; i++)
            {
                if(id_choice.Text[i]<'0' || id_choice.Text[i] > '9')
                {
                    MessageBox.Show("Nieprawidłowe ID!");
                    return;
                }
            }
            string sql = "SELECT * FROM pomiary WHERE id=" + id_choice.Text;
            SqlCommand cmd = new SqlCommand(sql, db);
            SqlDataReader DataReader = cmd.ExecuteReader();
            while (DataReader.Read())
            {
                pole.Text += "Temperatura: " + DataReader.GetValue(1) + " | Ciśnienie: " + DataReader.GetValue(2) + " | Wysokość: " + DataReader.GetValue(3) + " | Wilgotność: " + DataReader.GetValue(4) + " | Data: " + DataReader.GetValue(5) + " | Urządzenie: " + DataReader.GetValue(6) + "\n";
            }
        }
    }
}
